require("dotenv").config();

const express = require("express");
const cors = require("cors");
const db = require("./db");

const authRoutes = require("./routes/auth");
const flightRoutes = require("./routes/flights");
const bookingRoutes = require("./routes/bookings");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/flights", flightRoutes);
app.use("/api/bookings", bookingRoutes);

app.get("/", (req, res) => {
    res.json({ message: "SkyBook backend is running." });
});

app.get("/api/health", async (req, res) => {
    try {
        await db.query("SELECT 1");
        res.json({ status: "OK", database: "connected" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: "ERROR", database: "not connected" });
    }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log("==============================");
    console.log("SKYBOOK BACKEND");
    console.log("==============================");
    console.log(`Server: http://localhost:${PORT}`);
    console.log(`Flights: http://localhost:${PORT}/api/flights`);
    console.log("==============================");
});
