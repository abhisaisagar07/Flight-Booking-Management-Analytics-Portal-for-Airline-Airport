SKYBOOK BACKEND

1. Open .env
2. Change:
   DB_PASSWORD=CHANGE_THIS_TO_YOUR_MYSQL_PASSWORD
   to your actual MySQL root password.

3. Open PowerShell inside this folder.

4. Run:
   npm install

5. Run:
   npm run dev

6. Test in browser:
   http://localhost:5000/api/health
   http://localhost:5000/api/flights

Your frontend already points to:
http://localhost:5000
