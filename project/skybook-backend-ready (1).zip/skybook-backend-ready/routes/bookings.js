const express = require("express");
const crypto = require("crypto");
const db = require("../db");
const auth = require("../middleware/auth");

const router = express.Router();

router.post("/", auth, async (req, res) => {
    const connection = await db.getConnection();

    try {
        const { flight_id, passenger, seat_number } = req.body;

        if (!flight_id || !passenger || !passenger.full_name || !passenger.email || !passenger.phone) {
            return res.status(400).json({ message: "Passenger details are incomplete." });
        }

        await connection.beginTransaction();

        const [flights] = await connection.query(
            "SELECT id, price, available_seats FROM flights WHERE id = ? FOR UPDATE",
            [flight_id]
        );

        if (!flights.length) {
            await connection.rollback();
            return res.status(404).json({ message: "Flight not found." });
        }

        const flight = flights[0];

        if (flight.available_seats <= 0) {
            await connection.rollback();
            return res.status(400).json({ message: "Sorry, this flight is sold out." });
        }

        if (seat_number) {
            const [seat] = await connection.query(
                "SELECT id FROM bookings WHERE flight_id = ? AND seat_number = ? AND status = 'confirmed'",
                [flight_id, seat_number]
            );
            if (seat.length) {
                await connection.rollback();
                return res.status(409).json({ message: "That seat has already been booked." });
            }
        }

        const bookingReference = "SKY-" + crypto.randomBytes(4).toString("hex").toUpperCase();

        const [result] = await connection.query(
            `INSERT INTO bookings
             (booking_reference, user_id, flight_id, passenger_name, passenger_email,
              passenger_phone, passport_number, seat_number, amount, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed')`,
            [
                bookingReference, req.user.id, flight_id, passenger.full_name,
                passenger.email, passenger.phone, passenger.passport_number || null,
                seat_number || null, flight.price
            ]
        );

        await connection.query(
            "UPDATE flights SET available_seats = available_seats - 1 WHERE id = ?",
            [flight_id]
        );

        await connection.commit();

        res.status(201).json({
            message: "Booking confirmed.",
            data: {
                id: result.insertId,
                booking_reference: bookingReference,
                flight_id,
                passenger_name: passenger.full_name,
                seat_number: seat_number || null,
                amount: Number(flight.price),
                status: "confirmed"
            }
        });
    } catch (error) {
        try { await connection.rollback(); } catch {}
        console.error(error);
        res.status(500).json({ message: "Unable to complete booking." });
    } finally {
        connection.release();
    }
});

module.exports = router;
