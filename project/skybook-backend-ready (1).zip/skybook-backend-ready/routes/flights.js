const express = require("express");
const db = require("../db");

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        const [flights] = await db.query(`
            SELECT
                f.id, f.flight_number, f.departure_time, f.arrival_time,
                f.price, f.total_seats, f.available_seats, f.status, f.delay_minutes,
                o.id AS origin_id, o.code AS origin_code, o.name AS origin_name,
                o.city AS origin_city, o.country AS origin_country,
                d.id AS destination_id, d.code AS destination_code, d.name AS destination_name,
                d.city AS destination_city, d.country AS destination_country
            FROM flights f
            JOIN airports o ON f.origin_airport_id = o.id
            JOIN airports d ON f.destination_airport_id = d.id
            ORDER BY f.departure_time ASC
        `);

        const data = flights.map(f => ({
            id: f.id,
            flight_number: f.flight_number,
            departure_time: f.departure_time,
            arrival_time: f.arrival_time,
            price: Number(f.price),
            total_seats: f.total_seats,
            available_seats: f.available_seats,
            status: f.status,
            delay_minutes: f.delay_minutes,
            origin: {
                id: f.origin_id, code: f.origin_code, name: f.origin_name,
                city: f.origin_city, country: f.origin_country
            },
            destination: {
                id: f.destination_id, code: f.destination_code, name: f.destination_name,
                city: f.destination_city, country: f.destination_country
            }
        }));

        res.json({ data });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Unable to load flights." });
    }
});

module.exports = router;
