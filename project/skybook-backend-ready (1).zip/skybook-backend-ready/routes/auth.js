const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");

const router = express.Router();

function createToken(user) {
    return jwt.sign(
        { id: user.id, email: user.email },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
    );
}

router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ message: "Name, email and password are required." });
        }
        if (password.length < 6) {
            return res.status(400).json({ message: "Password must be at least 6 characters." });
        }

        const normalizedEmail = email.toLowerCase().trim();
        const [existing] = await db.query("SELECT id FROM users WHERE email = ?", [normalizedEmail]);

        if (existing.length) {
            return res.status(409).json({ message: "An account with this email already exists." });
        }

        const passwordHash = await bcrypt.hash(password, 10);
        const [result] = await db.query(
            "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
            [name.trim(), normalizedEmail, passwordHash]
        );

        const user = { id: result.insertId, name: name.trim(), email: normalizedEmail };
        const token = createToken(user);

        res.status(201).json({
            message: "Account created successfully.",
            data: { token, user }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Unable to create account." });
    }
});

router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: "Email and password are required." });
        }

        const [users] = await db.query(
            "SELECT id, name, email, password_hash FROM users WHERE email = ?",
            [email.toLowerCase().trim()]
        );

        if (!users.length) {
            return res.status(401).json({ message: "Invalid email or password." });
        }

        const user = users[0];
        const valid = await bcrypt.compare(password, user.password_hash);

        if (!valid) {
            return res.status(401).json({ message: "Invalid email or password." });
        }

        const token = createToken(user);

        res.json({
            message: "Login successful.",
            data: {
                token,
                user: { id: user.id, name: user.name, email: user.email }
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Unable to log in." });
    }
});

module.exports = router;
